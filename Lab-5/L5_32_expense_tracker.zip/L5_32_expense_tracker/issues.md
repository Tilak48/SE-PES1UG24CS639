# Static Code Analysis — Personal Expense Tracker

## Issues Identified

| Issue | Type | Line(s) | Description | Fix Approach |
|---|---|---:|---|---|
| Unsafe shell execution | Security — High | 61 | `os.system()` launches a shell command using a supplied path, creating a command-injection risk. | Replace shell execution with a safer cross-platform method. |
| Insecure temporary file creation | Security — Medium | 55 | `tempfile.mktemp()` can expose a race condition when creating temporary files. | Use `tempfile.NamedTemporaryFile()` with secure file creation. |
| Hardcoded temporary directory | Security — Medium | 8 | A fixed `/tmp/expense_reports` path may not exist on every operating system and is flagged by Bandit. | Use Python's system-provided temporary directory. |
| Hardcoded password | Security — Low | 5 | The bank-sync password is stored directly in the source code. | Read the password from an environment variable instead. |
| Broad exception handling | Code quality | 41 | Catching `Exception` can hide unexpected programming errors. | Handle the specific exception expected when no expenses exist. |
| Global statement | Code quality | 29 | `setBudget()` modifies a global variable, increasing coupling. | Refactor budget storage to avoid the `global` statement. |
| Inconsistent naming | Code style | 11–64 | Several functions and arguments use camelCase instead of Python's snake_case convention. | Rename functions and variables to snake_case. |
| Missing docstrings | Code style | 1, 11, 20, 28, 33, 38, 44, 49, 53, 59, 64 | The module and functions lack explanatory docstrings. | Add a module docstring and appropriate function docstrings. |
| Formatting violations | Code style | 15, 44, 74, 77 | Flake8 reports whitespace, blank-line, inline-comment, and line-length violations. | Apply PEP 8 formatting and split long lines. |
| Inefficient loop style | Code quality | 45–46 | Pylint recommends `enumerate()` instead of indexing through `range(len(...))`. | Iterate with `enumerate()` to access both index and expense. |

## Original Analysis Results

- Pylint score: 5.27/10
- Bandit: 4 findings
- Flake8: 4 findings

The original demonstration ran successfully. After fixing the issues, rerun all three tools and verify that the program still produces the expected expense totals and budget summary.
