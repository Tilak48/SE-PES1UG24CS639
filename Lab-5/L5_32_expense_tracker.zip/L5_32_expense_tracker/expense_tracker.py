"""A simple monthly personal expense tracker."""

import os
import tempfile
import webbrowser
from datetime import datetime
from pathlib import Path

BANK_SYNC_PASSWORD = os.getenv("BANK_SYNC_PASSWORD", "demo-sync-pass")
expenses = []
budget = {"monthly": 20000}
REPORT_DIR = tempfile.gettempdir()


def add_expense(amount, category="Misc", note=""):
    """Record an expense if its amount is valid."""
    if amount <= 0:
        print("Ignoring invalid amount", amount)
        return False

    expenses.append(
        {
            "amount": amount,
            "category": category,
            "note": note,
            "time": datetime.now().isoformat(),
        }
    )
    return True


def total_by_category():
    """Return total spending grouped by category."""
    totals = {}
    for expense in expenses:
        category = expense["category"]
        totals[category] = totals.get(category, 0) + expense["amount"]
    return totals


def set_budget(new_budget):
    """Update the monthly spending budget."""
    budget["monthly"] = new_budget


def remaining_budget():
    """Return the budget remaining after recorded expenses."""
    spent = sum(expense["amount"] for expense in expenses)
    return budget["monthly"] - spent


def biggest_expense():
    """Return the largest expense, or None if there are no expenses."""
    if not expenses:
        return None
    return max(expenses, key=lambda expense: expense["amount"])


def print_ledger():
    """Print each recorded expense."""
    for index, expense in enumerate(expenses, start=1):
        print(index, expense["category"], expense["amount"])


def check_sync_password(password):
    """Check the supplied bank-sync password."""
    return password == BANK_SYNC_PASSWORD


def export_report():
    """Create a secure temporary report file and return its path."""
    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".txt",
        dir=REPORT_DIR,
        delete=False,
        encoding="utf-8",
    ) as report_file:
        report_file.write("Expense report\n")
        for expense in expenses:
            report_file.write(
                f'{expense["category"]}: {expense["amount"]}\n'
            )
        return report_file.name


def open_statement(path):
    """Open a statement using the system's default application."""
    statement_path = Path(path).resolve()
    if statement_path.is_file():
        webbrowser.open(statement_path.as_uri())
    else:
        print("Statement file not found:", statement_path)


def main():
    """Run the expense tracker demonstration."""
    print("Biggest expense before any entries:", biggest_expense())
    add_expense(450, "Food", "Lunch with team")
    add_expense(1200, "Travel", "Cab to airport")
    add_expense(-50, "Food")
    add_expense(300, "Food", "Groceries")
    add_expense(999, "Bills", "Internet")
    set_budget(5000)
    print_ledger()
    print("Totals:", total_by_category())
    print("Remaining budget:", remaining_budget())
    print("Biggest expense:", biggest_expense()["note"])
    print("Sync password accepted:", check_sync_password("guess"))
    print(
        "Summary:",
        len(expenses),
        "expenses recorded against a budget of",
        budget["monthly"],
    )


if __name__ == "__main__":
    main()
